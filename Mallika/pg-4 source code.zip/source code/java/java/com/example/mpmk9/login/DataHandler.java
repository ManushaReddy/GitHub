package com.example.mpmk9.login;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.sql.SQLException;

/**
 * Created by mpmk9 on 2/24/2015.
 */
public class DataHandler {
    public static final String FNAME="FirstName";
    public static final String UNAME="UserName";
    public static final String PASSWORD="Password";
    public static final String RPASSWORD="RPassword";
    public static final String EMAIL="EMail";
    public static final String TABLE_NAME="mytable";
    public static final String DATA_BASE_NAME="mydatabase";
    public static final int DATABASE_VERSION= 1;
    public static final String TABLE_CREATE="create table mytable(FirstName text not null,UserName text not null,Password text not null,RPassword text not null,EMail text not null);";

    DataBaseHelper dbhelper;
    Context ctx;
    SQLiteDatabase db;
    public DataHandler(Context ctx)
    {
        this.ctx =ctx;
        dbhelper = new DataBaseHelper(ctx) ;
    }


    private static class DataBaseHelper extends SQLiteOpenHelper {
        public DataBaseHelper(Context ctx) {

            super(ctx, DATA_BASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            try {
Log.d("database","1");


                db.execSQL(TABLE_CREATE);
            }catch (Exception e){
                e.printStackTrace();
            }

        }



        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

           // db.execSQL("DROP TABLE IF EXITS mytable");
            //onCreate(db);

        }


    }

    public DataHandler open()
    {
        db = dbhelper.getWritableDatabase();
        return this;
    }

    public void close()
    {
        dbhelper.close();
    }

    public long insertData(String FirstName ,String UserName ,String Password ,String RPassword ,String EMail )
    {

        ContentValues content= new ContentValues();
        content.put(FNAME,FirstName);
        content.put(UNAME,UserName);
        content.put(PASSWORD,Password);
        content.put(RPASSWORD,RPassword);
        content.put(EMAIL,EMail);
        return db.insertOrThrow(TABLE_NAME,null, content);

    }

    public Cursor returnData(String UN,String pass)
    {
        return db.query(TABLE_NAME, new String[] {UN,pass},null,null,null,null,null);



    }

}


