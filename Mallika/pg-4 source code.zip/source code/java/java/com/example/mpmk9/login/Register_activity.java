package com.example.mpmk9.login;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by mpmk9 on 2/25/2015.
 */
public class Register_activity extends ActionBarActivity
        {

            Button Register;
            EditText UserName,FirstName,Password,RPassword,EMail;
            TextView username,firstname,password,rpassword,email;
            DataHandler handler;

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);
                Register =(Button) findViewById(R.id.Register);
                UserName=(EditText) findViewById(R.id.UserName);
                FirstName=(EditText) findViewById(R.id.FirstName);
                Password=(EditText) findViewById(R.id.Password);
                RPassword=(EditText) findViewById(R.id.RPassword);
                EMail=(EditText) findViewById(R.id.EMail);
                username=(TextView) findViewById(R.id.username);
                firstname=(TextView) findViewById(R.id.firstname);
                password=(TextView) findViewById(R.id.password);
                rpassword=(TextView) findViewById(R.id.rpassword);
                email=(TextView) findViewById(R.id.email);
                Register.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String getFname = FirstName.getText().toString();
                        String getUname = UserName.getText().toString();
                        String getPassword = Password.getText().toString();
                        String getRpassword=RPassword.getText().toString();
                        String getEmail=EMail.getText().toString();
                        handler =new DataHandler(getBaseContext());
                        handler.open();
                        long id=handler.insertData(getFname,getUname,getPassword,getRpassword,getEmail);
                        Toast.makeText(getBaseContext(), "Data Inserted successfully", Toast.LENGTH_LONG).show();
                        handler.close();
                        finish();
                    }
                });
            }



}
